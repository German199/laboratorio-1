# Clase 1

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Diferencias_JS_y_C.pdf
* Introducci�n_a_C.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=Xrfs720FjGI&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=1

