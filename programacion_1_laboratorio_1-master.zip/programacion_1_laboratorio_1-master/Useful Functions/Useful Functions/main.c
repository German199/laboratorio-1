#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int id;
    int name[20];
    int lastName[20];
    float salary;
    int isEmpty;

}Testing;

int main()
{
    printf("TodoOk\n");

    return 0;
}

// FUNCION BUSCAR EN UNA ESTRUCTURA SI ESTA VACIA SINO DEVUELVE EL INDICE
    int searchEmpty(Testing name[], int len)
{
    int indice = -1;
    for(int i = 0; i < len; i++)
    {
        if (name[i].isEmpty == 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

// FUNCION HARDCODEAR DATOS
int hardcoding(Testing name[], int tam, int cantidad)
{
    int counter = 0;
    Testing listaAuxiliar[] =
    {
        {7000, "Juan", "Perez", 15540, 0}, // EDITAR SEGUN ARRAY
    };

    if (cantidad <= tam && cantidad < 20)
    {
        for (int i = 0; i < cantidad; i++)
        {
            name[i] = listaAuxiliar[i];
            counter++;
        }
    }
    return counter;
}

// FUNCION MOSTRAR EN CONSOLA UN DATO DE UN ARRAY, DEBE SER LLAMADO
void mostrarDato(Testing nombre)
{
    printf("%d   %10s        %10s         %.2f          %02d\n",
           nombre.id,
           nombre.name,
           nombre.lastName,
           nombre.salary);
}
// FUNCION MOSTRAR TODOS LOS DATOS DE UN ARRAY SI NO ESTAN VACIOS
// LLAMA A LA FUNCION DE ARRIBA
void mostrarDatos(Testing nombre[], int len)
{
    int flag = 0;

    printf("\n\n-ID-      -NOMBRE-       -APELLIDO-        -SALARIO-       -SECTOR-\n");

    for(int i=0; i < len; i++)
    {
        if(nombre[i].isEmpty == 0)
        {
            mostrarDato(nombre[i]);
            flag = 1;
        }
    }
    if (flag == 0)
    {
        system("cls");
        printf("\nNo se han encontrados empleados en el sistema.\n");
    }
    printf("\n\n");

}
