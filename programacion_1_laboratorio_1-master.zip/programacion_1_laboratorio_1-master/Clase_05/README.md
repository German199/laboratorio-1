# Clase 5

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Arrays.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=u0buOpdkYT4&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=5

### Ejercicio
#### Objetivo:

Solicitar al usuario 5 n�meros, permitir listarlos por pantalla indicando el m�ximo, el m�nimo y el promedio. Permitir Modificar el valor de cualquiera de los n�meros cargados indicando el �ndice del mismo y su nuevo valor.

- Version: 0.1 del 29 diciembre de 2015
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   Utilizaci�n de arrays.