
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int getIntRange(int*, char*, char*,  int, int, int);
