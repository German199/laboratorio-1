# Material educativo Programaci�n I y Laboratorio I

## Tecnicaturas en programaci�n. UTN-FRA

#### Descripci�n:

En este repositorio se encontrar� el material educativo utiliziado en las materias Programaci�n I y Laboratorio I separado clase a clase.
Dentro de cada directorio que corresponde a una clase, se encontrar� un archivo README en donde se detallar� el contenido de dicha clase, generalmente compuesto por
uno o m�s apuntes, un videotutorial explicando la resoluci�n de un ejercicio y los archivos del programa resuelto en el video.

#### Contacto:
UTN-FRA. Extensi�n universitaria. Tecnicaturas en programaci�n. http://www.sistemas-utnfra.com.ar . tecnicaturas@fra.utn.edu.ar

